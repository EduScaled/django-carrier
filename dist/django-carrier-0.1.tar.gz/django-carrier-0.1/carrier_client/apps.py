from django.apps import AppConfig

class CarrierClientConfig(AppConfig):
    name = 'carrier_client'
